
#import <UIKit/UIKit.h>

//! Project version number for UITestSugarIOS.
FOUNDATION_EXPORT double UITestSugarIOSVersionNumber;

//! Project version string for UITestSugarIOS.
FOUNDATION_EXPORT const unsigned char UITestSugarIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UITestSugarIOS/PublicHeader.h>


